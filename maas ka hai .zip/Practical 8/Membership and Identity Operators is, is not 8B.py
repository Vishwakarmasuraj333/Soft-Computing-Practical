x = 5  
if (type(x) is int):
    print ("true")  
else:
    print ("false") 
